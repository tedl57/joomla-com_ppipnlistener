DROP TABLE IF EXISTS `#__ppipnlistener_log`;
